# Project instructions

- Prefer small, reviewable changes.
- Run formatting, Clippy, and tests before claiming success.
- Do not add dependencies without explaining the tradeoff.
