Review the selected code for correctness, security, maintainability, and
unnecessary allocation. Cite exact files and line ranges.
