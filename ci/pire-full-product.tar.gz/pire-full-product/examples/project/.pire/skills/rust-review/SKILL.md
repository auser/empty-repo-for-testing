# Rust review skill

Check ownership, error propagation, bounded resource usage, cancellation or
process cleanup, public API shape, tests, and Clippy compatibility.
