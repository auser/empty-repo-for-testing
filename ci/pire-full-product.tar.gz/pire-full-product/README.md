# Pire

Pire is a clean Rust coding-agent harness inspired by Pi's small-core,
extensible product shape. It is not a source port. The architecture is designed
around explicit provider, agent, tool, resource, session, and interface
boundaries.

## What is included

- Provider-neutral agent loop with bounded steps and tool calls.
- OpenAI and OpenAI-compatible HTTP providers.
- Local command-provider protocol for bundled model runtimes.
- Deterministic offline provider for development and tests.
- Workspace-confined file, search, edit, and process tools.
- Trust and approval controls for mutating operations.
- Append-only JSONL sessions.
- `PIRE.md`, `AGENTS.md`, and bounded `@file` context loading.
- Interactive, one-shot, and JSON event modes.
- Cross-platform Rust CI with formatting, Clippy, and tests.

## Configuration precedence

```text
compiled defaults
  < user config
  < WORKSPACE/.pire/config.toml
  < explicit --config FILE
  < PIRE_* environment variables
  < CLI flags
```

Nested environment variables use `__`:

```bash
PIRE_PROVIDER__KIND=open_ai_compatible
PIRE_PROVIDER__BASE_URL=http://127.0.0.1:8080/v1
PIRE_PROVIDER__MODEL=local-model
PIRE_AGENT__MAX_STEPS=24
PIRE_TOOLS__APPROVAL=auto
```

## Quick start

```bash
cargo run -p pire-cli -- doctor
cargo run -p pire-cli -- --provider offline --print explain this repository
```

For edits or process execution, explicitly trust the workspace and select an
approval mode:

```bash
cargo run -p pire-cli -- \
  --trust \
  --approval auto \
  --provider openai-compatible \
  --base-url http://127.0.0.1:8080/v1 \
  --model local-model \
  --print \
  fix the failing tests
```

See `docs/LOCAL_MODELS.md`, `docs/ARCHITECTURE.md`, and
`docs/CONFIGURATION.md`.
