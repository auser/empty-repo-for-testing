use std::{
    io::{Read, Write},
    process::{Command, Stdio},
    sync::mpsc,
    thread,
    time::Duration,
};

use pire_core::{CompletionRequest, CompletionResponse, Provider, ProviderError};
use wait_timeout::ChildExt;

#[derive(Debug)]
pub struct CommandProvider {
    command: Vec<String>,
    timeout: Duration,
    max_response_bytes: usize,
}

impl CommandProvider {
    pub fn new(
        command: Vec<String>,
        timeout: Duration,
        max_response_bytes: usize,
    ) -> Result<Self, ProviderError> {
        if command.is_empty() {
            return Err(ProviderError::Configuration(
                "command provider requires a non-empty command".to_owned(),
            ));
        }
        if max_response_bytes == 0 {
            return Err(ProviderError::Configuration(
                "command provider max_response_bytes must be greater than zero".to_owned(),
            ));
        }
        Ok(Self {
            command,
            timeout,
            max_response_bytes,
        })
    }
}

impl Provider for CommandProvider {
    fn name(&self) -> &str {
        "command"
    }

    fn complete(&self, request: &CompletionRequest) -> Result<CompletionResponse, ProviderError> {
        let program = self
            .command
            .first()
            .ok_or_else(|| ProviderError::Configuration("command is empty".to_owned()))?;
        let mut child = Command::new(program)
            .args(&self.command[1..])
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .spawn()
            .map_err(|error| ProviderError::Process(error.to_string()))?;

        let mut stdin = child
            .stdin
            .take()
            .ok_or_else(|| ProviderError::Process("provider stdin is unavailable".to_owned()))?;
        serde_json::to_writer(&mut stdin, request)
            .map_err(|error| ProviderError::Process(error.to_string()))?;
        stdin
            .write_all(b"\n")
            .map_err(|error| ProviderError::Process(error.to_string()))?;
        drop(stdin);

        let stdout = child
            .stdout
            .take()
            .ok_or_else(|| ProviderError::Process("provider stdout is unavailable".to_owned()))?;
        let stderr = child
            .stderr
            .take()
            .ok_or_else(|| ProviderError::Process("provider stderr is unavailable".to_owned()))?;
        let max = self.max_response_bytes;
        let (tx, rx) = mpsc::channel();
        let tx_stdout = tx.clone();
        let _stdout_reader = thread::spawn(move || {
            let _ = tx_stdout.send((true, read_bounded(stdout, max)));
        });
        let _stderr_reader = thread::spawn(move || {
            let _ = tx.send((false, read_bounded(stderr, max)));
        });

        let status = match child
            .wait_timeout(self.timeout)
            .map_err(|error| ProviderError::Process(error.to_string()))?
        {
            Some(status) => status,
            None => {
                child
                    .kill()
                    .map_err(|error| ProviderError::Process(error.to_string()))?;
                let _ = child.wait();
                return Err(ProviderError::Process(format!(
                    "provider exceeded {:?}",
                    self.timeout
                )));
            }
        };
        let first = rx
            .recv()
            .map_err(|error| ProviderError::Process(error.to_string()))?;
        let second = rx
            .recv()
            .map_err(|error| ProviderError::Process(error.to_string()))?;
        let mut stdout = String::new();
        let mut stderr = String::new();
        for (is_stdout, result) in [first, second] {
            let value = result?;
            if is_stdout {
                stdout = value;
            } else {
                stderr = value;
            }
        }
        if !status.success() {
            return Err(ProviderError::Process(format!(
                "provider exited with {}: {}",
                status
                    .code()
                    .map_or_else(|| "signal".to_owned(), |code| code.to_string()),
                stderr
            )));
        }
        serde_json::from_str(&stdout)
            .map_err(|error| ProviderError::InvalidResponse(error.to_string()))
    }
}

fn read_bounded(mut reader: impl Read, max: usize) -> Result<String, ProviderError> {
    let take = u64::try_from(max)
        .map_err(|_| ProviderError::Configuration("response limit is too large".to_owned()))?;
    let mut bytes = Vec::new();
    reader
        .by_ref()
        .take(take.saturating_add(1))
        .read_to_end(&mut bytes)
        .map_err(|error| ProviderError::Process(error.to_string()))?;
    if bytes.len() > max {
        return Err(ProviderError::InvalidResponse(format!(
            "provider output exceeds {max} bytes"
        )));
    }
    String::from_utf8(bytes).map_err(|error| ProviderError::InvalidResponse(error.to_string()))
}
