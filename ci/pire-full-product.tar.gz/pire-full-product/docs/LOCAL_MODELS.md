# Local models

Pire supports local models through two deliberately small interfaces.

## OpenAI-compatible HTTP

Use this for llama.cpp server, LM Studio, Ollama's OpenAI-compatible endpoint,
LocalAI, vLLM, or another compatible runtime:

```toml
[provider]
kind = "open_ai_compatible"
model = "local-model"
base_url = "http://127.0.0.1:8080/v1"
api_key_env = ""
```

When no key is required, omit `api_key_env` entirely rather than setting an
empty environment-variable name.

Equivalent CLI:

```bash
pire \
  --provider openai-compatible \
  --base-url http://127.0.0.1:8080/v1 \
  --model local-model
```

The runtime must expose Chat Completions tool calls. Model quality and tool-call
schema adherence vary by model and server.

## Command provider

The command provider lets Pire launch a bundled or separately installed local
runtime adapter without introducing an in-process C/C++ ABI into the agent
core.

Pire writes one `CompletionRequest` JSON object to the child process's stdin.
The child writes one `CompletionResponse` JSON object to stdout. Stderr is
reserved for diagnostics. Execution is time- and output-bounded.

```toml
[provider]
kind = "command"
model = "local-gguf"
command = ["./bin/pire-model-adapter", "--model", "models/model.gguf"]
```

This seam is suitable for a future Rust-native runtime, llama.cpp wrapper, or
MVM-contained model worker. The adapter remains replaceable and crash-isolated.
