# Configuration

## Precedence

Pire resolves configuration in this order, with later layers winning:

1. Rust defaults.
2. Per-user `config.toml` from the platform application-config directory.
3. `.pire/config.toml` in the selected workspace.
4. A required file supplied through `--config`.
5. `PIRE_*` environment variables.
6. Sparse CLI overrides.

An omitted CLI flag remains absent and does not replace a file or environment
value.

## Adding settings

Most settings should be file/environment-only. Add the resolved field and its
Rust default to the appropriate settings struct. Serde and the environment
source automatically expose it through TOML and `PIRE_SECTION__FIELD`.

Only frequently changed per-invocation settings should also be added to
`CliOverrides`. This avoids duplicating every configuration field merely to
make it a flag.

## Secrets

Configuration stores the name of an API-key environment variable, not the
secret itself. For example:

```toml
[provider]
api_key_env = "OPENAI_API_KEY"
```

Local OpenAI-compatible endpoints can omit `api_key_env`.
