# Architecture

Pire follows a strict dependency direction:

```text
pire-cli ───────────────► pire-core
    │
    └────► pire-providers ─► pire-core
```

`pire-core` contains no knowledge of Clap, environment variables, terminal
rendering, or concrete model vendors. It owns:

- conversation and tool-call types;
- the bounded agent loop;
- tool contracts and built-in tools;
- workspace confinement;
- approval contracts;
- resource loading;
- append-only sessions;
- structured events.

`pire-providers` implements model transport adapters. The initial adapters are:

- deterministic offline;
- OpenAI Chat Completions;
- OpenAI-compatible HTTP for local or hosted endpoints;
- out-of-process command protocol.

`pire-cli` owns process concerns:

- configuration composition;
- CLI parsing;
- workspace trust;
- terminal approval prompts;
- interactive and one-shot interfaces;
- diagnostics and process exit codes.

This keeps the core embeddable and allows a future TUI, RPC server, desktop
client, or MVM-hosted interface to consume the same agent events.
