# Corvus inspiration

Pire borrows architectural lessons rather than code:

- explicit `bootstrap`, `doctor`, `approval`, `providers`, `skills/resources`,
  `tools`, `security`, and observability boundaries;
- provider adapters behind a stable core contract;
- supervised approval as a first-class subsystem;
- secure defaults and bounded gateway/process behavior;
- doctor commands that report configuration and runtime readiness.

Pire intentionally remains narrower than Corvus. It is a coding-agent harness,
not a daemon, hardware gateway, scheduler, channel hub, or general automation
platform. Optional capabilities should stay outside the minimal core until a
real product need justifies them.
