# Security model

Pire treats model output, project instructions, file references, and tool
arguments as untrusted input.

- Project instruction files are loaded only with `--trust`.
- Read operations remain workspace-confined.
- Existing paths are canonicalized before access.
- New paths require a canonical parent inside the workspace.
- Symlink traversal outside the workspace is rejected.
- Writes and process execution require both workspace trust and approval.
- Processes are spawned directly, not through a shell.
- Process time and output are bounded.
- Input, resource, provider-response, file, and session sizes are bounded.
- API secrets are read from named environment variables and are not serialized
  into resolved configuration output.

`approval = "ask"` fails closed when no interactive terminal is available.
